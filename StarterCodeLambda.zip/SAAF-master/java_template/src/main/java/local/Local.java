/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package local;

import java.util.HashMap;

/**
 *
 * @author robertcordingly
 */
public class Local {
    
    // int main enables testing function from cmd line
    public static void main(String[] args) {
        // Context c = new Context() {
        //     @Override
        //     public String getAwsRequestId() {
        //         return "";
        //     }

        //     @Override
        //     public String getLogGroupName() {
        //         return "";
        //     }

        //     @Override
        //     public String getLogStreamName() {
        //         return "";
        //     }

        //     @Override
        //     public String getFunctionName() {
        //         return "";
        //     }

        //     @Override
        //     public String getFunctionVersion() {
        //         return "";
        //     }

        //     @Override
        //     public String getInvokedFunctionArn() {
        //         return "";
        //     }

        //     @Override
        //     public CognitoIdentity getIdentity() {
        //         return null;
        //     }

        //     @Override
        //     public ClientContext getClientContext() {
        //         return null;
        //     }

        //     @Override
        //     public int getRemainingTimeInMillis() {
        //         return 0;
        //     }

        //     @Override
        //     public int getMemoryLimitInMB() {
        //         return 0;
        //     }

        //     @Override
        //     public LambdaLogger getLogger() {
        //         return new LambdaLogger() {
        //             @Override
        //             public void log(String string) {
        //                 System.out.println("LOG:" + string);
        //             }
        //         };
        //     }
        // };

        // // Create an instance of the class
        // Hello lt = new Hello();

        // // Create a request object
        // Request req = new Request();

        // // Grab the name from the cmdline from arg 0
        // String name = (args.length > 0 ? args[0] : "");

        // // Load the name into the request object
        // req.setName(name);

        // // Report name to stdout
        // System.out.println("cmd-line param name=" + req.getName());

        // Run the function
        //HashMap<String, Object> resp = lt.handleRequest(req, c);
        
        // Print out function result
        //System.out.println("function result:" + resp.toString());
    }
}
