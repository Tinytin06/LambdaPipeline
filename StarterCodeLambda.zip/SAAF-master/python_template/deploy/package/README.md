Pip packages placed in this directory will be deployed with the function.
