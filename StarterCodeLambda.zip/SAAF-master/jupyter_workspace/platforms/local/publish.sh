#!/bin/bash

echo "Published!"